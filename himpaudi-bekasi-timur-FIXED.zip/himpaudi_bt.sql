-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 12, 2025 at 07:37 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `himpaudi_bt`
--

-- --------------------------------------------------------

--
-- Table structure for table `berita`
--

CREATE TABLE `berita` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `content` text DEFAULT NULL,
  `excerpt` varchar(500) DEFAULT NULL,
  `author` varchar(150) DEFAULT NULL,
  `thumbnail` varchar(255) DEFAULT NULL,
  `published_at` datetime DEFAULT NULL,
  `status` enum('draft','published') DEFAULT 'published',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `berita`
--

INSERT INTO `berita` (`id`, `title`, `slug`, `content`, `excerpt`, `author`, `thumbnail`, `published_at`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Pelatihan Peningkatan Kualitas Guru PAUD', 'pelatihan-peningkatan-kualitas-guru-paud', 'Pelatihan untuk guru PAUD membahas pendekatan bermain sambil belajar...', 'Pelatihan untuk guru PAUD membahas pendekatan bermain sambil belajar...', 'Admin', 'berita1.jpg', '2025-10-10 17:18:48', 'published', '2025-10-10 17:18:48', '2025-10-17 13:07:48'),
(2, 'Kegiatan Lomba Kreativitas Anak', 'lomba-kreativitas-anak', 'Anak-anak menunjukkan kreativitasnya dalam lomba menggambar...', 'Anak-anak menunjukkan kreativitasnya...', 'Admin', 'berita2.jpg', '2025-10-03 17:18:48', 'published', '2025-10-10 17:18:48', '2025-10-17 13:18:39'),
(3, 'Sosialisasi Program Baru HIMPAUDI', 'sosialisasi-program-baru', 'HIMPAUDI memperkenalkan program baru untuk pemberdayaan guru...', 'HIMPAUDI memperkenalkan program baru...', 'Admin', 'berita3.jpg', '2025-09-26 17:18:48', 'published', '2025-10-10 17:18:48', '2025-10-17 13:18:45'),
(4, 'Pelayanan Konsultasi Pendidikan PAUD Gratis', 'pelayanan-konsultasi-paud', 'Setiap bulan ada jadwal konsultasi gratis bagi orang tua dan guru...', 'Setiap bulan ada jadwal konsultasi gratis...', 'Admin', 'hero4.jpg', '2025-09-19 17:18:48', 'published', '2025-10-10 17:18:48', '2025-10-10 17:18:48'),
(5, 'Kunjungan Kerja ke Lembaga PAUD Terbaik', 'kunjungan-kerja-lembaga-paud', 'Tim HIMPAUDI mengunjungi lembaga PAUD terbaik sebagai studi banding...', 'Tim HIMPAUDI mengunjungi...', 'Admin', 'hero5.jpg', '2025-09-10 17:18:48', 'published', '2025-10-10 17:18:48', '2025-10-10 17:18:48');

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `message` text DEFAULT NULL,
  `status` enum('open','closed') DEFAULT 'open',
  `ticket_code` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `downloads`
--

CREATE TABLE `downloads` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `visible_public` tinyint(1) DEFAULT 1,
  `uploaded_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `downloads`
--

INSERT INTO `downloads` (`id`, `title`, `filename`, `description`, `visible_public`, `uploaded_at`) VALUES
(1, 'Formulir Pendaftaran Anggota', 'form_pendaftaran.pdf', 'Formulir resmi pendaftaran anggota HIMPAUDI Bekasi Timur', 1, '2025-10-10 17:18:48'),
(2, 'Surat Edaran Kegiatan', 'surat_edaran.pdf', 'Surat edaran kegiatan HIMPAUDI', 1, '2025-10-10 17:18:48');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `is_internal` tinyint(1) DEFAULT 0,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`id`, `title`, `description`, `start_date`, `end_date`, `location`, `is_internal`, `created_at`) VALUES
(1, 'Pelatihan Guru PAUD', 'Pelatihan: pendekatan kreatif', '2025-10-17', '2025-10-17', 'Aula Kantor HIMPAUDI', 0, '2025-10-10 17:18:48'),
(2, 'Rapat Pengurus', 'Rapat koordinasi internal pengurus', '2025-10-24', '2025-10-24', 'Ruang Rapat', 1, '2025-10-10 17:18:48');

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `id` int(11) NOT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `caption` varchar(255) DEFAULT NULL,
  `uploaded_by` int(11) DEFAULT NULL,
  `uploaded_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `gallery`
--

INSERT INTO `gallery` (`id`, `filename`, `caption`, `uploaded_by`, `uploaded_at`) VALUES
(1, 'kegiatan1.png', 'Kegiatan Pelatihan Guru', 1, '2025-10-10 17:18:48'),
(2, 'kegiatan2.png', 'Lomba Kreativitas Anak', 1, '2025-10-10 17:18:48'),
(3, 'kegiatan3.png', 'Rapat Pengurus', 1, '2025-10-10 17:18:48');

-- --------------------------------------------------------

--
-- Table structure for table `lembaga_paud`
--

CREATE TABLE `lembaga_paud` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `kepala` varchar(150) DEFAULT NULL,
  `jumlah_siswa` int(11) DEFAULT 0,
  `jumlah_guru` int(11) DEFAULT 0,
  `kontak` varchar(150) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lembaga_paud`
--

INSERT INTO `lembaga_paud` (`id`, `nama`, `alamat`, `kepala`, `jumlah_siswa`, `jumlah_guru`, `kontak`, `created_at`) VALUES
(1, 'TK Ceria', 'Jl. Pelita No.1, Bekasi Timur', 'Siti Aminah', 80, 8, '081234567890', '2025-10-10 17:18:48'),
(2, 'PAUD Permata Hati', 'Jl. Merpati No.2', 'Budi Santoso', 60, 6, '081234567891', '2025-10-10 17:18:48'),
(3, 'KB Bintang Kecil', 'Komplek Makmur Blok A', 'Rina Marlina', 40, 5, '081234567892', '2025-10-10 17:18:48'),
(4, 'PAUD Harapan Bangsa', 'Jl. Mawar No.3', 'Dewi Lestari', 55, 7, '081234567893', '2025-10-10 17:18:48'),
(5, 'TK Pelangi', 'Jl. Anggrek No.4', 'Adi Putra', 70, 9, '081234567894', '2025-10-10 17:18:48');

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `meta` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE `members` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `lembaga` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `dok_upload` varchar(255) DEFAULT NULL,
  `registration_id` int(10) UNSIGNED DEFAULT NULL,
  `nip_nuptk` varchar(50) DEFAULT NULL,
  `tempat_lahir` varchar(100) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `jenis_kelamin` varchar(20) DEFAULT NULL,
  `pendidikan_terakhir` varchar(100) DEFAULT NULL,
  `jabatan` varchar(100) DEFAULT NULL,
  `status_pegawai` varchar(50) DEFAULT NULL,
  `provinsi` varchar(100) DEFAULT NULL,
  `kabupaten` varchar(100) DEFAULT NULL,
  `kecamatan` varchar(100) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `diklat` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `member_registration`
--

CREATE TABLE `member_registration` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `provinsi` varchar(100) DEFAULT NULL,
  `kabupaten` varchar(100) DEFAULT NULL,
  `kecamatan` varchar(100) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `nip_nuptk` varchar(50) DEFAULT NULL,
  `kta_lama` varchar(100) DEFAULT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `tempat_lahir` varchar(100) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `jenis_kelamin` varchar(20) DEFAULT NULL,
  `pendidikan_terakhir` varchar(100) DEFAULT NULL,
  `jabatan` varchar(100) DEFAULT NULL,
  `status_pegawai` varchar(50) DEFAULT NULL,
  `lembaga_asal` varchar(100) DEFAULT NULL,
  `no_hp` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `diklat` text DEFAULT NULL,
  `foto` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `member_registration`
--

INSERT INTO `member_registration` (`id`, `user_id`, `provinsi`, `kabupaten`, `kecamatan`, `alamat`, `created_at`, `nip_nuptk`, `kta_lama`, `nama`, `tempat_lahir`, `tanggal_lahir`, `jenis_kelamin`, `pendidikan_terakhir`, `jabatan`, `status_pegawai`, `lembaga_asal`, `no_hp`, `email`, `diklat`, `foto`) VALUES
(1, NULL, 'Jawa Barat', 'Kota Bekasi', 'Bekasi Timur', 'djadoqjd', '2025-10-21 20:16:39', '83838833', NULL, 'danusubma', 'pacitan', '0000-00-00', '', '', '', '', '', '', 'danusubma.id@gmail.com', 'Mahir, TOT Dasar, TOT Mahir', '1761052599_logo_Universitas-Gunadarma-thumb.png'),
(2, NULL, 'DKI Jakarta', 'Kabupaten Bekasi', 'Bekasi Selatan', 'djadoqjd', '2025-11-06 18:46:02', '83838833', NULL, 'danusubma', 'pacitan', '0000-00-00', '', '', '', '', '', '', 'danusubma.id@gmail.com', 'Dasar, Mahir, Lanjut', '1762429562_img_0003.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE `profiles` (
  `id` int(11) NOT NULL DEFAULT 1,
  `org_name` varchar(200) DEFAULT NULL,
  `visi` text DEFAULT NULL,
  `misi` text DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `kontak` varchar(200) DEFAULT NULL,
  `instagram` varchar(200) DEFAULT NULL,
  `facebook` varchar(200) DEFAULT NULL,
  `whatsapp` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `profiles`
--

INSERT INTO `profiles` (`id`, `org_name`, `visi`, `misi`, `alamat`, `kontak`, `instagram`, `facebook`, `whatsapp`, `created_at`) VALUES
(1, 'HIMPAUDI Kecamatan Bekasi Timur', 'Menjadi wadah pengembangan PAUD yang profesional dan berkualitas di Bekasi Timur.', '1. Meningkatkan kualitas tenaga pendidik PAUD; 2. Memfasilitasi koordinasi antar lembaga; 3. Meningkatkan partisipasi masyarakat.', 'Kantor HIMPAUDI Bekasi Timur, Jl. Contoh No.1, Bekasi Timur, Jawa Barat.', 'Telp: (021) 0000-0000 | Email: himpaudi.bt@example.org', 'https://instagram.com/himpaudi_bekasitimur', 'https://facebook.com/himpaudi.bekasitimur', '+628112345678', '2025-10-10 17:18:48');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `k` varchar(100) NOT NULL,
  `v` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`k`, `v`) VALUES
('items_per_page', '6'),
('site_tagline', 'Mendukung Pendidikan Anak Usia Dini di Bekasi Timur'),
('site_title', 'HIMPAUDI Kecamatan Bekasi Timur');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) UNSIGNED NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `role` enum('admin','user') DEFAULT 'user',
  `active` tinyint(1) DEFAULT 1,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `name`, `email`, `role`, `active`, `created_at`) VALUES
(1, 'admin', '$2b$12$IkhR86FERG1bHHxu.VTE/ePXYAjWr.23dVuvq9g0ynFdCGoFSLaJW', 'Admin Utama', 'admin@himpaudi-bt.local', 'admin', 1, '2025-10-10 17:18:48'),
(2, 'danu', '$2y$10$IwFyap2hynlGFIvZ3ZwCCuaChG8afuGd2KmqRcqp4BE8NW2Y.QrAK', 'Danu Subma', 'danusubma.id@gmail.com', 'user', 1, '2025-11-12 11:41:05'),
(3, 'danu12', '$2y$10$A25P83C6cUIfW97dt9dmCO/ENvZUM0BqqmR4r5cmPNOuMqS54vaxi', 'danusubma.id@gmail.com', 'danusubma.id@gmail.com', 'user', 1, '2025-11-12 12:02:13'),
(4, 'danu11', '$2y$10$/W5AYLW2poswjfYr06tq8ulyuqACP1DwmlNXWlAMg19X4veEz/H6K', 'danusubma.id@gmail.com', 'danuaja@gmail.com', 'user', 1, '2025-11-12 13:13:28');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `berita`
--
ALTER TABLE `berita`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indexes for table `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `downloads`
--
ALTER TABLE `downloads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lembaga_paud`
--
ALTER TABLE `lembaga_paud`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_member_registration` (`registration_id`),
  ADD KEY `fk_members_user` (`user_id`);

--
-- Indexes for table `member_registration`
--
ALTER TABLE `member_registration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profiles`
--
ALTER TABLE `profiles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`k`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `berita`
--
ALTER TABLE `berita`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `contact_messages`
--
ALTER TABLE `contact_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `downloads`
--
ALTER TABLE `downloads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `lembaga_paud`
--
ALTER TABLE `lembaga_paud`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `members`
--
ALTER TABLE `members`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `member_registration`
--
ALTER TABLE `member_registration`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `members`
--
ALTER TABLE `members`
  ADD CONSTRAINT `fk_member_registration` FOREIGN KEY (`registration_id`) REFERENCES `member_registration` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_members_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
