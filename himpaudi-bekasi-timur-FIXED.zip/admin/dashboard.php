<?php
require_once __DIR__ . '/../src/config.php';
if (!isset($_SESSION['user'])) {
    header('Location: login.php');
    exit;
}
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Dashboard</title></head>
<body>
<h1>Welcome, <?php echo htmlspecialchars($_SESSION['user']['name']); ?></h1>
<ul>
    <li><a href="berita_crud.php">Manage Berita</a></li>
    <li><a href="../tools/update_admin_password.php">(Tool) Reset Admin Password</a></li>
    <li><a href="logout.php">Logout</a></li>
</ul>
</body>
</html>
