<?php
require_once __DIR__ . '/../src/config.php';
if (!isset($_SESSION['user']) || ($_SESSION['user']['role'] ?? '') !== 'admin') {
    // allow admin only for CRUD
    header('Location: login.php');
    exit;
}

$action = $_GET['action'] ?? '';
if ($action === 'delete' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    if (isset($pdo)) {
        $stmt = $pdo->prepare('DELETE FROM berita WHERE id = :id');
        $stmt->execute([':id' => $id]);
    } else {
        $mysqli = mysqli_conn();
        $mysqli->query("DELETE FROM berita WHERE id = $id");
    }
    header('Location: berita_crud.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['title'])) {
    $title = $_POST['title'];
    $slug = $_POST['slug'] ?: strtolower(preg_replace('/[^a-z0-9]+/i', '-', $title));
    $content = $_POST['content'] ?? '';
    $excerpt = $_POST['excerpt'] ?? '';
    $author = $_SESSION['user']['name'] ?? $_SESSION['user']['username'];
    $status = $_POST['status'] ?? 'draft';

    // thumbnail upload
    $thumb = null;
    if (!empty($_FILES['thumbnail']['name'])) {
        $uploaddir = __DIR__ . '/../uploads/';
        if (!is_dir($uploaddir)) mkdir($uploaddir, 0755, true);
        $fname = basename($_FILES['thumbnail']['name']);
        $target = $uploaddir . time() . '_' . preg_replace('/[^a-zA-Z0-9.\-_]/', '_', $fname);
        if (move_uploaded_file($_FILES['thumbnail']['tmp_name'], $target)) {
            $thumb = basename($target);
        }
    }

    if (isset($pdo)) {
        $stmt = $pdo->prepare('INSERT INTO berita (title, slug, content, excerpt, author, thumbnail, published_at, status) VALUES (:title,:slug,:content,:excerpt,:author, :thumbnail, NOW(), :status)');
        $stmt->execute([':title'=>$title, ':slug'=>$slug, ':content'=>$content, ':excerpt'=>$excerpt, ':author'=>$author, ':thumbnail'=>$thumb, ':status'=>$status]);
    } else {
        $mysqli = mysqli_conn();
        $t = $mysqli->real_escape_string($title);
        $s = $mysqli->real_escape_string($slug);
        $c = $mysqli->real_escape_string($content);
        $e = $mysqli->real_escape_string($excerpt);
        $a = $mysqli->real_escape_string($author);
        $th = $mysqli->real_escape_string($thumb);
        $st = $mysqli->real_escape_string($status);
        $mysqli->query("INSERT INTO berita (title, slug, content, excerpt, author, thumbnail, published_at, status) VALUES ('$t','$s','$c','$e','$a','$th',NOW(),'$st')");
    }

    header('Location: berita_crud.php');
    exit;
}

// fetch list
$rows = [];
if (isset($pdo)) {
    $rows = $pdo->query('SELECT * FROM berita ORDER BY created_at DESC')->fetchAll();
} else {
    $mysqli = mysqli_conn();
    $res = $mysqli->query('SELECT * FROM berita ORDER BY created_at DESC');
    while ($r = $res->fetch_assoc()) $rows[] = $r;
}
?>
<!doctype html>
<html><head><meta charset="utf-8"><title>Manage Berita</title></head><body>
<h2>Berita - Manage</h2>
<p><a href="dashboard.php">Back to Dashboard</a></p>

<h3>Add Berita</h3>
<form method="post" enctype="multipart/form-data">
    <label>Title<br><input type="text" name="title" required></label><br>
    <label>Slug (optional)<br><input type="text" name="slug"></label><br>
    <label>Excerpt<br><textarea name="excerpt"></textarea></label><br>
    <label>Content<br><textarea name="content"></textarea></label><br>
    <label>Thumbnail<br><input type="file" name="thumbnail"></label><br>
    <label>Status<br><select name="status"><option value="draft">draft</option><option value="published">published</option></select></label><br>
    <button type="submit">Create</button>
</form>

<h3>Existing</h3>
<table border="1" cellpadding="6"><tr><th>ID</th><th>Title</th><th>Author</th><th>Created</th><th>Action</th></tr>
<?php foreach ($rows as $r): ?>
<tr>
<td><?php echo $r['id']; ?></td>
<td><?php echo htmlspecialchars($r['title']); ?></td>
<td><?php echo htmlspecialchars($r['author']); ?></td>
<td><?php echo $r['created_at']; ?></td>
<td><a href="?action=delete&id=<?php echo $r['id']; ?>" onclick="return confirm('Delete?')">Delete</a></td>
</tr>
<?php endforeach; ?>
</table>
</body></html>
