<?php
// admin/login.php - simple login form + handling
require_once __DIR__ . '/../src/config.php';

$err = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    if (isset($pdo)) {
        $stmt = $pdo->prepare('SELECT * FROM users WHERE username = :u AND active = 1 LIMIT 1');
        $stmt->execute([':u' => $username]);
        $user = $stmt->fetch();
    } else {
        $mysqli = mysqli_conn();
        $esc = $mysqli->real_escape_string($username);
        $res = $mysqli->query("SELECT * FROM users WHERE username = '$esc' AND active = 1 LIMIT 1");
        $user = $res ? $res->fetch_assoc() : null;
    }

    if ($user) {
        if (password_verify($password, $user['password'])) {
            // set session
            $_SESSION['user'] = [
                'id' => $user['id'],
                'username' => $user['username'],
                'name' => $user['name'] ?? $user['username'],
                'role' => $user['role'] ?? 'user'
            ];
            header('Location: dashboard.php');
            exit;
        } else {
            $err = 'Invalid username or password.';
        }
    } else {
        $err = 'Invalid username or password.';
    }
}
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Admin Login</title></head>
<body>
<h2>Admin Login</h2>
<?php if ($err): ?><p style="color:red;"><?php echo htmlspecialchars($err); ?></p><?php endif; ?>
<form method="post" action="">
    <label>Username<br><input type="text" name="username" required></label><br><br>
    <label>Password<br><input type="password" name="password" required></label><br><br>
    <button type="submit">Login</button>
</form>
</body>
</html>
