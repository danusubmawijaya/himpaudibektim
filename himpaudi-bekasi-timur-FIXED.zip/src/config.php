<?php
// src/config.php - minimal, adjust to your environment
ini_set('display_errors', 1);
error_reporting(E_ALL);

date_default_timezone_set('Asia/Jakarta');

$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';
$db_name = 'himpaudi_bt';

// mysqli connection (fallback)
$mysqli = new mysqli($db_host, $db_user, $db_pass, $db_name);
if ($mysqli->connect_error) {
    die('Koneksi database gagal: ' . $mysqli->connect_error);
}
$mysqli->set_charset('utf8mb4');

// PDO connection (recommended)
try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8mb4", $db_user, $db_pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $e) {
    // If PDO fails, we continue using mysqli
    // echo 'PDO Connection failed: ' . $e->getMessage();
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
