<?php
// src/db.php - helper functions using PDO if available, else mysqli
require_once __DIR__ . '/config.php';

function pdo() {
    global $pdo;
    return $pdo ?? null;
}

function mysqli_conn() {
    global $mysqli;
    return $mysqli ?? null;
}
?>
