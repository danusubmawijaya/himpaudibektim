<?php
// tools/update_admin_password.php - run once to set admin password to admin123
require_once __DIR__ . '/../src/config.php';

$new = 'admin123';
$hash = password_hash($new, PASSWORD_BCRYPT);

// prefer PDO if available
if (isset($pdo)) {
    $stmt = $pdo->prepare('UPDATE users SET password = :p WHERE username = :u');
    $stmt->execute([':p' => $hash, ':u' => 'admin']);
    echo "Admin password updated to 'admin123' using PDO. Please delete this script after running.\n";
} else {
    $mysqli = mysqli_conn();
    if ($mysqli) {
        $u = $mysqli->real_escape_string('admin');
        $p = $mysqli->real_escape_string($hash);
        $mysqli->query("UPDATE users SET password = '$p' WHERE username = '$u'") or die($mysqli->error);
        echo "Admin password updated to 'admin123' using mysqli. Please delete this script after running.\n";
    } else {
        echo "No DB connection available.\n";
    }
}
?>
