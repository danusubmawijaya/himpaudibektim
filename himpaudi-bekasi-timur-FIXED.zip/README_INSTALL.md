# HIMPAUDI Bekasi Timur - FIXED Package

This package includes helper admin panel files and scripts to integrate with your existing project database.

## Steps
1. Place these files inside your web root (e.g. C:\xampp\htdocs\himpaudi or /var/www/html/himpaudi).
2. Import the included SQL (`himpaudi_bt.sql`) into MySQL (phpMyAdmin).
3. Edit `src/config.php` to match your DB credentials.
4. Run `php tools/update_admin_password.php` once to set admin password to `admin123`.
5. Ensure `uploads/` directory is writable by the webserver.
6. Open `http://localhost/himpaudi/admin/login.php` and login with `admin` / `admin123`.

## What I included
- src/config.php (db connections)
- src/db.php
- admin/login.php, admin/dashboard.php, admin/logout.php, admin/berita_crud.php
- tools/update_admin_password.php
- himpaudi_bt.sql (copied from your uploaded SQL)

This is a helper patch: copy/merge files into your extracted project folder. If you want, I can also attempt to directly modify files inside your uploaded .rar and provide a full replacement zip.
